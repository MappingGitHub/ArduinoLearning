Dimmable LED Project worked %100 correct. 

Note: Pulse Width Modulation, or PWM, is a 
technique for getting analog results with 
digital means. Digital control is used to 
create a square wave, a signal switched 
between on and off.

LED value can be from 0 o 255
Potentiometer value can be from 0 to 1023
 
Source:  Paul McWhorter  YouTube channel
https://toptechboy.com/arduino-tutorial-14-dimmable-led-project/
https://www.youtube.com/watch?v=7wKdxsvXAFo&list=PLGs0VKk2DiYw-L-RibttcvK-WBZm8WLEP&index=14
