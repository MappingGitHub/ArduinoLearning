BLINKING LED WITH Pushbutton in Different Frequencies

Read about Pushbutton detection function and  "State Change Detection (Edge Detection)"

Links used for this project:

http://www.arduino.cc/en/Tutorial/ButtonStateChange
https://create.arduino.cc/projecthub/reverendfuzzy/simple-on-off-pushbutton-f637a7
https://www.arduino.cc/reference/en/language/functions/time/millis/